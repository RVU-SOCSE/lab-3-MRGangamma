echo "job 1: Display Date"
date
sleep 3

echo "job 2: Display current user"
whoami
sleep 3

echo "job 3: Display Calendar"
cal
sleep 2

echo "job 4: list the files"
ls
sleep 3

echo "job 5: Display my system date"
date+"%T"
sleep 1

echo "job 6:Display the present working directory"
pwd

